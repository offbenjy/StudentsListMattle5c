export const envrionment = {
    apiUrl: 'http://localhost:5000',
}