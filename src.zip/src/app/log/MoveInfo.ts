export class MoveInfo {
    studentName!: string;
    targetClazz!: string;
  }